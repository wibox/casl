To run this code just execute main.py and it will take care of everything.
Log files are stored inside logs/ and the final visualization is in result/