To run this laboratory you just need to run main.py which will take care of everything.
To inspect the code that generates the instances of the R.V.s, everything you need is inside generator.py