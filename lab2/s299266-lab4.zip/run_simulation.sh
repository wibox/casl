python3 config_manager.py && ./execute.sh && python3 warhol.py
