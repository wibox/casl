To see the simulator's output, run main.py to use the software with default parameters (i.e. two servers)
The number of servers can be increased via their predisposed arg: --num-servers
